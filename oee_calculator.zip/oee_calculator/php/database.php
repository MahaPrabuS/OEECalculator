<?php
	$hostname = "localhost"; // Replace with your database hostname
	$username = "root"; // Replace with your database username
	$password = ""; // Replace with your database password
	$database = "new_oee_calculator"; // Replace with your database name

	// Create a database connection
	$conn = new mysqli($hostname, $username, $password, $database);

	// Check the connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
?>